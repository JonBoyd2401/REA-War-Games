# REA War Games — Developer Pack

Start with docs/COMBINATION_BENCHMARK.md and docs/HOW_REA_WORKS.md, then read the
current white paper: docs/REA_SaaS_Protection_White_Paper_Combinations.pdf.
Earlier workflow, reconstruction and original reports remain historical evidence.
lab/ is the original deliberately unsafe/hardened comparison. Its demo token is public.
lab-v2/ is the session-protected teaching fixture; read its README for startup.

Run the 58 application/scoring tests with a supported Node version:
    node --test lab/test/wargame.test.mjs lab-v2/test/session-boundaries.test.mjs reconstruction/test.mjs reconstruction/gated-test.mjs boundary-study/test.mjs agent-benchmark/test.mjs combination-study/test.mjs

Install pinned REA and run the browser experiments using docs/REPRODUCE.md.
This smaller pack contains source, tests, runners and guides. Historical captures,
their integrity manifest and the evidence verifier are in the full research pack:
https://github.com/JonBoyd2401/REA-War-Games
Use that full repository for node verify-evidence.mjs and evidence links.

Hard blocks mean refusal of specific unauthorised requests while permitted quotes
still work. No universal REA-proof or production-ready security claim is made.
